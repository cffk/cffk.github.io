* Version 1.0 of random number routines
* Author: Charles Karney <karney@princeton.edu>
* Date: 1999-08-05 08:56:46 -0400
      integer ran_k,ran_s,ran_c
      parameter (ran_k=100,ran_s=8,ran_c=34)
